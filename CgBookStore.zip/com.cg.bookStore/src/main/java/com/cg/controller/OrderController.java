package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Customer;
import com.cg.model.Order;
import com.cg.service.IOrderService;

@RestController
public class OrderController {

	@Autowired
	IOrderService iOrderService;

	@RequestMapping("/order/{city}")
	public Order orderTo(HttpServletRequest request, @PathVariable("city") String city) {
		HttpSession session = request.getSession();
		Customer customer = (Customer) session.getAttribute("user");
		Order order = new Order();
		order.setCustomer(customer);
		order.setCity(city);
		order.setCountry(customer.getCountry());
		order.setOrderedStatus("Processing");
		order.setPaymentMethod("Cash On delivery");
		order.setZipCode(customer.getZipCode());
		order.setStreetAddress(customer.getAddress());
		iOrderService.save(order);
		return order;
	}

	@RequestMapping("/orderDetails")
	public Order orderDetails(@RequestParam("orderId") int orderId) {
		Order order = iOrderService.findByOrderId(orderId);
		return order;
	}

	@RequestMapping("/listOfOrders")
	public List<Order> listOfReviews() {
		return iOrderService.findAll();
	}

	@RequestMapping("/deleteOrder")
	public String deleteOrder(@RequestParam("orderId") int orderId) {
		iOrderService.delete(iOrderService.findByOrderId(orderId));
		return "Order Deleted";
	}

	@RequestMapping("/editOrder")
	public Order editOrder(@RequestParam("orderId") int orderId, Model model) {
		Order order = iOrderService.findByOrderId(orderId);
		model.addAttribute("command", order);
		return order;
	}

	@PostMapping("/updateOrder")
	public Order updateOrder(@ModelAttribute("order") Order order) {
		iOrderService.save(order);
		return order;
	}

}

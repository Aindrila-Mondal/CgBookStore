package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Admin;
import com.cg.model.Book;
import com.cg.model.Customer;
import com.cg.model.Review;
import com.cg.service.IAdminService;
import com.cg.service.IBookService;
import com.cg.service.IReviewService;

@RestController
public class ReviewController {

	@Autowired
	IBookService iBookService;
	@Autowired
	IReviewService iReviewService;
	@Autowired
	IAdminService iAdminService;

	List<Book> cartlist = new ArrayList<Book>();

	@RequestMapping("/addToCart")
	public String addToCart(@RequestParam("bookId") Integer bookId) {
		Book book = iBookService.findByBookId(bookId);
		cartlist.add(book);
		return "added to cart";
	}

	@RequestMapping("/viewCart")
	public List<Book> view_Cart() {
		return cartlist;
	}

	@RequestMapping("/listOfReviews")
	public List<Review> listOfReviews() {
		return iReviewService.findAll();
	}

	@PostMapping("/giveReview")
	public Review give_Review(@RequestBody Review review, @RequestParam("bookId") int bookId,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		Customer customer = (Customer) session.getAttribute("user");
		Book book = iBookService.findByBookId(bookId);
		review.setCustomer(customer);
		review.setBook(book);
		iReviewService.save(review);
		return review;
	}

	@RequestMapping("/updateCart")
	public List<Double> cartDetails(HttpServletRequest request) {
		List<Double> subtotal = new ArrayList<Double>();
		for (int i = 0; i < cartlist.size(); i++) {
			int quantity = Integer.parseInt(request.getParameter("quantity" + i));
			int bookId = Integer.parseInt(request.getParameter("bookId"));
			Book book = iBookService.findByBookId(bookId);
			subtotal.add(book.getPrice() * quantity);
			book.setQunatity(book.getQunatity() - quantity);
			iBookService.save(book);
		}
		return subtotal;
	}

	@RequestMapping("/deleteReview")
	public String deleteReview(@RequestParam("reviewId") int reviewId, HttpServletRequest request) {
		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("user");
		if (admin != null) {
			iReviewService.delete(iReviewService.findByReviewId(reviewId));
			return "Review Deleted";
		} else
			return "Only admin can delete";
	}

	@RequestMapping("/editReview")
	public Review editReview(@RequestParam("reviewId") int reviewId, Model model) {
		Review review = iReviewService.findByReviewId(reviewId);
		model.addAttribute("command", review);
		return review;
	}

	@PostMapping("/updateReview")
	public String updateCustomer(@ModelAttribute("review") Review review) {
		iReviewService.save(review);
		return "Review updated";
	}

}

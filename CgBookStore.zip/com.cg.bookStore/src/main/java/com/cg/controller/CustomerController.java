package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Admin;
import com.cg.model.Customer;
import com.cg.service.ICustomerService;

@RestController
public class CustomerController {

	@Autowired
	ICustomerService iCustomerService;

	@RequestMapping("/listOfCustomers")
	public List<Customer> listOfCustomer() {
		return iCustomerService.findAll();
	}

	@PostMapping("/createCustomer")
	public Customer createCustomer(@RequestBody Customer customer) {
		iCustomerService.save(customer);
		return customer;
	}

	@RequestMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("customerId") int customerId, HttpServletRequest request) {
		HttpSession session = request.getSession();
		Admin admin = (Admin) session.getAttribute("user");
		if (admin != null) {
			iCustomerService.delete(iCustomerService.findByCustomerId(customerId));
			return "deleted Customer";
		} else
			return "Only admin can delete";
	}

	@RequestMapping("/editCustomer")
	public Customer editCustomer(@RequestParam("customerId") int customerId, Model model) {
		Customer customer = iCustomerService.findByCustomerId(customerId);
		model.addAttribute("command", customer);
		return customer;
	}

	@PostMapping("/updateCustomer")
	public Customer updateCustomer(@ModelAttribute("customer") Customer customer) {
		iCustomerService.save(customer);
		return customer;
	}
}

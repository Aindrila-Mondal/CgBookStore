package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Book;
import com.cg.model.Category;
import com.cg.model.Review;
import com.cg.service.IBookService;
import com.cg.service.ICategoryService;
import com.cg.service.IReviewService;

@RestController
public class BookController {

	@Autowired
	IBookService iBookService;
	@Autowired
	ICategoryService iCategoryService;
	@Autowired
	IReviewService iReviewService;

	@PostMapping("/add_Book")
	public Book add_Book(@RequestBody Book book) {
		book.setCategory(iCategoryService.findByCategory(book.getCategory().getCategoryName()));
		iBookService.save(book);
		return book;
	}

	@PostMapping("/add_Category")
	public Category add_Category(@RequestBody Category category) {
		iCategoryService.save(category);
		return category;
	}

	@RequestMapping("/searchByCategory/{category}")
	public List<Book> searchByCategory(@PathVariable("category") String category) {
		Category category1 = iCategoryService.findByCategory(category);
		List<Book> list = iBookService.findByCategory(category1);
		System.out.println(list);
		return list;
	}

	@RequestMapping("/view_Book")
	public Book view_Book(@RequestParam("bookId") Integer bookId) {
		Book book = iBookService.findByBookId(bookId);
		return book;
	}

	@RequestMapping("/listOfAllBooks")
	public List<Book> listOfAllBooks() {
		return iBookService.findAll();
	}

	@RequestMapping("/editBook")
	public Book editBook(@RequestParam("bookId") int bookId, Model model) {
		Book book = iBookService.findByBookId(bookId);
		model.addAttribute("command", book);
		return book;
	}

	@PostMapping("/updateBook")
	public Book updateBook(@ModelAttribute("book") Book book) {
		iBookService.save(book);
		return book;
	}

	@RequestMapping("/deleteBook")
	public String deletBook(@RequestParam("bookId") int bookId) {
		Book book = iBookService.findByBookId(bookId);
		Review review = iReviewService.findByBook(book);
		if (review == null) {
			iBookService.delete(book);
			return "Book deleted";
		} else {
			return "It has review and can't be deleted";
		}
	}

	@RequestMapping("/editCategory")
	public Category editCategory(@RequestParam("categoryId") int categoryId, Model model) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		model.addAttribute("command", category);
		return category;
	}

	@PostMapping("/updateCategory")
	public Category updateCategory(@ModelAttribute("category") Category category) {
		iCategoryService.save(category);
		return category;
	}

	@RequestMapping("/deleteCategory")
	public String deleteCategory(@RequestParam("categoryId") int categoryId) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		Category category1 = iCategoryService.findByCategory("NA");
		List<Book> booksOfCategory = iBookService.findByCategory(category);
		for (Book book : booksOfCategory) {
			book.setCategory(category1);
			iBookService.save(book);
		}
		iCategoryService.remove(category);
		return "Deleted Succesfully";
	}

}

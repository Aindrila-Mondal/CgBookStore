package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.model.Book;
import com.cg.model.Review;

@Repository("iReviewDao")
public interface IReviewDao extends JpaRepository<Review, Integer> {

	public Review findByBook(Book book);

	public Review findByReviewId(int reviewId);

}

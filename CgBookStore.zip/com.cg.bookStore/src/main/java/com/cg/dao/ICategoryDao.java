package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.model.Category;

@Repository("iCategoryDao")
public interface ICategoryDao extends JpaRepository<Category, Integer> {

	@Query("SELECT a FROM Category a WHERE a.categoryName=:categoryName")
	public Category findCategory(@Param("categoryName") String categoryName);

	@Query("SELECT a FROM Category a WHERE a.categoryId=:categoryId")
	public Category findCategoryById(@Param("categoryId") Integer categoryId);
}

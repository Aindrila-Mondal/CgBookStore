package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.model.Book;
import com.cg.model.Category;

@Repository("iBookDao")
public interface IBookDao extends JpaRepository<Book, Integer> {

	public Book findByBookId(int bookId);

	public List<Book> findByCategory(Category category);
}

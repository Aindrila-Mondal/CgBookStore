package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.model.Customer;

@Repository("iCustomerDao")
public interface ICustomerDao extends JpaRepository<Customer, Integer> {

	public Customer findByCustomerId(int customerId);

	public Customer findByEmailId(String emailId);

}

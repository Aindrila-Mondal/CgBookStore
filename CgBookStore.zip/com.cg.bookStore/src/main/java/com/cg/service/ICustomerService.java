package com.cg.service;

import java.util.List;

import com.cg.model.Customer;

public interface ICustomerService {

	public Customer findByCustomerId(int customerId);

	public Customer findByEmailId(String emailId);

	public Customer save(Customer customer);

	public void delete(Customer findByCustomerId);

	public List<Customer> findAll();

}

package com.cg.service;

import java.util.List;

import com.cg.model.Book;
import com.cg.model.Review;

public interface IReviewService {

	public Review findByBook(Book book);

	public Review save(Review review);

	public List<Review> findAll();

	public Review findByReviewId(int reviewId);

	public void delete(Review review);
}

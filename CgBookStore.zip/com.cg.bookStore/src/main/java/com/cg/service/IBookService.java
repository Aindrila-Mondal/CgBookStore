package com.cg.service;

import java.util.List;

import com.cg.model.Book;
import com.cg.model.Category;

public interface IBookService {

	public Book findByBookId(int bookId);

	public List<Book> findByCategory(Category category);

	public Book save(Book book);

	public List<Book> findAll();

	public void delete(Book book);

}

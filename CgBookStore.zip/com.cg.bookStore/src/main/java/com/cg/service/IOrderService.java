package com.cg.service;

import java.util.List;

import com.cg.model.Customer;
import com.cg.model.Order;

public interface IOrderService {
	public Order findByOrderId(int orderId);

	public Order findByCustomer(Customer customer);

	public Order save(Order order);

	public void delete(Order order);

	public List<Order> findAll();
}

package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IReviewDao;
import com.cg.model.Book;
import com.cg.model.Review;

@Service("iReviewService")
public class IReviewServiceImpl implements IReviewService {

	@Autowired
	IReviewDao iReviewDao;

	@Override
	public Review findByBook(Book book) {
		// TODO Auto-generated method stub
		if (iReviewDao.findByBook(book) != null) {
			return iReviewDao.findByBook(book);
		} else {
			return null;
		}
	}

	public Review save(Review review) {
		return iReviewDao.save(review);
	}

	@Override
	public List<Review> findAll() {
		// TODO Auto-generated method stub
		return iReviewDao.findAll();
	}

	@Override
	public Review findByReviewId(int reviewId) {
		// TODO Auto-generated method stub
		return iReviewDao.findByReviewId(reviewId);
	}

	@Override
	public void delete(Review review) {
		// TODO Auto-generated method stub
		iReviewDao.delete(review);

	}

}

package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookDao;
import com.cg.model.Book;
import com.cg.model.Category;

@Service("iBookService")
public class IBookServiceImpl implements IBookService {

	@Autowired
	IBookDao iBookDao;

	@Override
	public Book findByBookId(int bookId) {
		// TODO Auto-generated method stub
		Book book = iBookDao.findByBookId(bookId);
		if (book != null) {
			return book;
		} else {
			return book;
		}
	}

	@Override
	public List<Book> findByCategory(Category category) {
		// TODO Auto-generated method stub
		List<Book> list = iBookDao.findByCategory(category);
		if (list.get(0) != null) {
			return list;
		} else {
			return list;
		}
	}

	public Book save(Book book) {
		return iBookDao.save(book);
	}

	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return iBookDao.findAll();
	}

	@Override
	public void delete(Book book) {
		iBookDao.delete(book);
	}

}

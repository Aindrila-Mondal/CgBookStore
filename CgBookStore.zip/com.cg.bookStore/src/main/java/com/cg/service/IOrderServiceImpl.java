package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IOrderDao;
import com.cg.model.Customer;
import com.cg.model.Order;

@Service("iOrderService")
public class IOrderServiceImpl implements IOrderService {

	@Autowired
	IOrderDao iOrderDao;

	@Override
	public Order findByOrderId(int orderId) {
		// TODO Auto-generated method stub
		Order order = iOrderDao.findByOrderId(orderId);

		if (order != null) {
			return order;
		} else {
			return order;
		}
	}

	@Override
	public Order findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Order order = iOrderDao.findByCustomer(customer);
		if (order != null) {
			return order;
		} else {
			return order;
		}
	}

	public Order save(Order order) {
		return iOrderDao.save(order);
	}

	@Override
	public void delete(Order order) {
		// TODO Auto-generated method stub
		iOrderDao.delete(order);
	}

	@Override
	public List<Order> findAll() {
		// TODO Auto-generated method stub
		return iOrderDao.findAll();
	}

}
